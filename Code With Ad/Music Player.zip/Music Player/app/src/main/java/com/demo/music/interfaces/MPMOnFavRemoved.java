package com.demo.music.interfaces;

import com.demo.music.model.MPMSongModel;


public interface MPMOnFavRemoved {
    void onFavRemoved(MPMSongModel mPMSongModel);
}
