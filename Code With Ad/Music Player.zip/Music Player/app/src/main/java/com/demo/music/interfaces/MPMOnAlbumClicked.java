package com.demo.music.interfaces;

import com.demo.music.model.MPMAlbumModel;


public interface MPMOnAlbumClicked {
    void OnAlbumClicked(MPMAlbumModel mPMAlbumModel);
}
