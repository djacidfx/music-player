package com.demo.music.interfaces;

import com.demo.music.model.MPMSongModel;


public interface MPMonSeeMoreClicked {
    void onSeeMoreClicked(String str, MPMSongModel mPMSongModel, boolean z);
}
