package com.demo.music.utils;


public enum PlaybackStatus {
    PLAYING,
    PAUSED
}
