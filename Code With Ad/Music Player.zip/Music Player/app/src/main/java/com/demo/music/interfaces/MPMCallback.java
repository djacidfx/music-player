package com.demo.music.interfaces;


public interface MPMCallback {
    void onClick(int i);
}
