package com.demo.music.interfaces;


public interface MPMPlaylistDialogListener {
    void onCancelClicked();

    void onSaveClicked(String str);
}
